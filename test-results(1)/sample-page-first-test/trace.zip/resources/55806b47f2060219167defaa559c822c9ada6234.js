$(document).ready(function(){

});

$(document).on('click','.likes_like_btn', function(e){
   e.preventDefault();
   
   var container = $(this).parents('.likes_block').parent();
   
   var type = $(this).data('type');
   var item_id = $(this).data('item_id');
   
   var tab = $('body').attr('class');
   
   $.post(
        '/likes/like',
        {
            'type' : type,
            'item_id' : item_id,
            'tab' : tab
        },
        function(data){
            $(container).html(data)
        }
   );
   
});

$(document).on('click','.likes_unlike_btn', function(e){
   e.preventDefault();
   
   var container = $(this).parents('.likes_block').parent();
   var type = $(this).data('type');
   var item_id = $(this).data('item_id');
   
   var tab = $('body').attr('class');
   
   $.post(
        '/likes/unlike',
        {
            'type' : type,
            'item_id' : item_id,
            'tab' : tab
        },
        function(data){
            $(container).html(data);
        }
   );
   
});

$(document).on('click','.likes_other_people_btn', function(e){
   e.preventDefault();
   
   var type = $(this).data('type');
   var item_id = $(this).data('item_id');

   var tab = $('body').attr('class');
   
   $.post(
        '/likes/wholiked',
        {
            'type' : type,
            'item_id' : item_id,
            'tab' : tab,
            'norender' : 1
        },
        function(data){
            var others = data.others;
            var content = '<ul id="likes_container">'
            + '<span class="popup_close"><a href="#" title="Close Who Liked"><img src="/image/responsive/close-cross.jpg" alt="Close"></a></span>'
            + '<h1 class="popup_heading">People Who Liked It</h1>';
            $.each(others, function(index) {
                content += '<li><img class="more_likes" alt="user photography" src="'+others[index].photo+'" /> '+others[index].dname+'</li>';
            });
            content += '</ul>';
            openPopup('likes_wholiked',content);
        },
        'json'
   );
   
});