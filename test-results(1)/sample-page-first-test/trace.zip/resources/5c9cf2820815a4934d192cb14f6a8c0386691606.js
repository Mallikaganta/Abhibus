if( document.getElementById('myLinksDiv') ){
    $('.myLinksLis .edit_my_links').on('click',function(e){
        e.preventDefault();
        var my_link = $(this).parent().find('.my_links').attr('href');
        var my_link_name = $(this).parent().find('.my_links').html();
        var my_li = $(this).parent();
        var my_id = my_li.attr('id').replace('myLink','');

        var edit_content = '<input type="text" class="my_link_name_edit" value="" /><br/>'+
            '<input type="text" class="my_link_edit" value="" />'+
            '<input type="button" class="my_link_save" value="OK" /><br/>'+
            '<span class="my_links_save_msg">Save your modifications by clicking on Save (Bottom right)</span>';

        my_li.html(edit_content);

        my_li.find('.my_link_edit').val(my_link);
        my_li.find('.my_link_name_edit').val(my_link_name);
    });


    $('.myLinksLis .my_link_save').on('click',function(e){
        e.preventDefault();
        var my_link = $(this).parent().find('.my_link_edit').val();
        var my_link_name = $(this).parent().find('.my_link_name_edit').val();
        var my_li = $(this).parent();

        my_li.html('<a class="my_links" href="'+my_link+'" target="_blank" title="'+my_link_name+'">'+my_link_name+'</a><a class="edit_my_links" href="javascript:void()"><img src="/image/pencil_grey.png" width="12" title="Edit Link" alt="Edit Link" /></a><a class="delete_my_links" href="javascript:void()"><img src="/image/mydesk/delete.gif" width="12" title="Delete Link" alt="Delete Link" /></a><img class="drag_my_links" src="/image/mydesk/move_up_down.gif" width="12" title="Move Link" alt="Move Link" />');

    });
}