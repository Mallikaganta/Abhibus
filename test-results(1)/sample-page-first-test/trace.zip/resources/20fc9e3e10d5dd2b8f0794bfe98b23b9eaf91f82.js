$().ready(function() {
    
    $(document).on('click', '#sendPageForm .Send', function(){
	
		//alert($('#email').val());
		var email       = $('#sendtofriend #email').val();       
		var urlOfPage   = $('#sendtofriend #urlOfPage').val();       
		var name        = $('#sendtofriend #name').val();       
		var message     = $('#sendtofriend #message').val();   
                name = name.replace("<", "#");
                name = name.replace(">", "!");
		$.post(
            '/news/sendtofriend/',
            {
                email:email,
                urlOfPage:urlOfPage,
				name:name,
				message:message
            },			
            function(response){
                //alert(response)
                $('#sendtofriend #success').html(response).fadeIn(500).delay(2000).fadeOut(500);
                
                },
            'json'
            );
            setTimeout(function(){closePopup('popup_sendtofriend');}, 3000);
        
    });

});
