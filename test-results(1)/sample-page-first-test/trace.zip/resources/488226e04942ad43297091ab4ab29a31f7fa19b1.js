$(document).ready(function() {
     /*$('body').on('click', 'a[href^="#"]', function(e){
        e.preventDefault();
        var href    = $(this).attr('href');
        var target  = $(href);
        if(typeof(target.offset()) !== 'undefined'){
            var fromtop     = target.offset().top - 200;
            $('html, body').animate({ scrollTop: (fromtop) });
            if(history && "pushState" in history) {
                history.pushState({}, document.title, window.location.pathname + href);
                return false;
            }
        }
     });*/
   
    var onglet = $('#tab').val();
    var news_id = $('#news_id').val();

    $(document).on('click', '#like', function(e){
        e.preventDefault();
        $(this).prop('disabled',true);
        ajaxLike(onglet,news_id);
    });
     
    $(document).on('click','#like_top',function(e){
        e.preventDefault();
        $(this).prop('disabled',true);
        ajaxLike(onglet,news_id);
    });

    $(document).on('click', '#unlike_top',function(e){
        e.preventDefault();
        $(this).prop('disabled',true);
        ajaxUnlike(onglet,news_id);
    });

    $(document).on('click','#like_bottom',function(e){
        e.preventDefault();
        $(this).prop('disabled',true);
        ajaxLike(onglet,news_id);
    });

    $(document).on('click','#unlike_bottom',function(e){
        e.preventDefault();
        $(this).prop('disabled',true);
        ajaxUnlike(onglet,news_id);
    });
    //}
    
  
    function ajaxLike(onglet,news_id){
	    //alert("clicked");
        $.ajax({
            url:'/'+onglet+'/like/'+news_id,
            success:function(response){
                var json_str = '';
                
                if(response.indexOf('{') > -1){
                    json_str = $.parseJSON(response);
                }
                
                if(json_str.error){
                   alert(json_str.error); 
                }else{
				      $('#like_cookie_machine').hide().html(response);
				      //alert(response);
				      //alert($(response).filter('#like_results_new').html());
				      var like_results_new = $(response).filter('#like_results_new').html();
				      var like_top_results_new = $(response).filter('#like_top_results_new').html();
				      var like_bottom_results_new = $(response).filter('#like_bottom_results_new').html();
              $('#like_results').html(like_results_new);
				      $('#like_top_results').html(like_top_results_new);
				      $('#like_bottom_results').html(like_bottom_results_new);
                }
            },
            failure:function(){
	           alert("Like failed.");
            }
        });
    }
	
	function ajaxUnlike(onglet,news_id){
	    //alert("clicked");
        $.ajax({
            url:'/'+onglet+'/unlike/'+news_id,
            success:function(response){
                var json_str = '';
                
                if(response.indexOf('{') > -1){
                    json_str = $.parseJSON(response);
                }

                if(json_str.error){
                   alert(json_str.error); 
                }else{
	            $('#like_cookie_machine').hide().html(response);
				      //alert(response);
				      //alert($(response).filter('#like_results_new').html());
				      var like_results_new = $(response).filter('#like_results_new').html();
				      var like_top_results_new = $(response).filter('#like_top_results_new').html();
				      var like_bottom_results_new = $(response).filter('#like_bottom_results_new').html();
	            $('#like_results').html(like_results_new);
				      $('#like_top_results').html(like_top_results_new);
				      $('#like_bottom_results').html(like_bottom_results_new);
				      $('#results_new').hide();
                }
            },
            failure:function(){
	           alert("Unlike failed.");
            }
        });		
    }
	
        
	
//	$('.visit_card').bind({
//		
//		mouseenter: function() {
//			var popUp = $(this).children('.popup');
//			popUp.css('display', 'block');
//
//                            
//
//		},
//                mouseleave: function(e) {
//                    var popUp = $(this).children('.popup');
//                    if(!popUp.is(':hover'))
//                        $(this).css('display', 'none');
//
//                }
//	});
        $(".visit_card").mouseenter(function(){
    
    
            $(this).children('.popup').show();
        }).mouseleave(function(){
            var someElement = this;
            $(someElement).children('.popup').hide();
        });
        
        $('.visit_card').click(function(){
            $(this).children('.popup').show();
        });

        $(document).on('click', '.bcard_close', function(){
            $(this).parents('.popup').hide();
        });
        
});

function show_news_likes(tab, news_id) {

	var user_display_name = $('#user_display_name').val();
	var like_users_str = '<span class="popup_close"><a href="#" title="Close Other People Who Likes"><img src="/image/responsive/close-cross.jpg" alt="Close"></a></span>';

        like_users_str += '<div id="news_likes_container">';

        $.ajax({
            type: 'POST',
            url: '/news/newslikes',
            data: {
                tab: tab,
                news_id : news_id
            },
            success: function(data){
                var total_likes = parseInt(data.total_likes);
                var i_liked = data.liked ? 1 : 0;
                var users_nb = data.users.length;
                
                var unknown_likes = ( total_likes - i_liked - users_nb );

                if( users_nb > 0 ){
                    like_users = data.users;

                    for(var i=0;i<users_nb;i++) {
                        if(like_users[i] != '' && like_users[i].display_name != user_display_name) {
                            like_users_str += '<div><img class="more_likes" src="'+like_users[i].photo+'" alt="user photography" />'+like_users[i].display_name+'</div>';
                        }
                    }

                    var people_person = '';

                    if(users_nb == 1) {
                        people_person = 'person';
                    }
                    else {
                        people_person = 'people';
                    }

                    if( unknown_likes > 0 ){
                        like_users_str += '<div>Information on '+ unknown_likes +' '+people_person+' not available</div>';
                    }

                    like_users_str += '</div>';

                    openPopup('news_like_users_popup_box',like_users_str);

                    return false;
                }
                
            },
            dataType : 'json'
        });
}

$(document).on('click', '.show_news_likes', function(){
    var news_id = $(this).data('cid');
    var tab = $('body').attr('class');
    show_news_likes(tab, news_id);
});