/*
Accordion style drop downs.
Structure for html to make this work
<a class="acDropDownLink" data-id="dd1" href="[URL to go to if javascript is disabled]">Title 1</a>
<div class="acDropDown" id="dd1" name="dd1">
CONTENT TO HIDE
</div>
*/




function addDropDowns(autoCollapse){
	autoCollapse = typeof autoCollapse !== 'undefined' ? autoCollapse : true;
	/*add the onclick event to the link*/

	$('.acDropDownLink').bind('click keydown',function(e){
		if(e.keyCode !== 9){
			var id = $(this).attr('data-id');
			var acDropDown = $('#' + id );
			$('.acDropDown').each(function(){
				if(autoCollapse){
					if($(this).is(':visible')){
						$(this).fadeOut('fast',function(){
							$(this).removeClass('acDropDownClick');
						});	
					}
				}
			});
			/*add the class to make the dropdown fade in*/
			if(!acDropDown.hasClass('acDropDownClick')){
				
				acDropDown.fadeIn('fast', function(){
					if(!$.support.opacity){
						$(this).get(0).style.removeAttribute('filter');
					}
				}).addClass('acDropDownClick');
			}else{
				/*fade out the dropdown if it is already open*/
				acDropDown.fadeOut('fast',function(){
					acDropDown.removeClass('acDropDownClick');
				});
			}
			
			return false;
		}
	});
};