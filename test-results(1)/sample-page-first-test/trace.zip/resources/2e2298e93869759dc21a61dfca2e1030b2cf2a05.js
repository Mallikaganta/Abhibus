
$(document).ready(
    function(){
        
        $('#add_comment_btn').click(
            function(){
                $('#add_comment_form').toggle("slow");
                $('#add_comment_btn div.comment_show_hide_btn').toggle();
            }
            );

        $(document).on('click','.like-comment',function(){
            $(this).prop('disabled',true);
            var cid = $(this).data('cid');
            like_comment(cid);
        });
        
        $(document).on('click','.unlike-comment',function(){
            $(this).prop('disabled',true);
            var cid = $(this).data('cid');
            unlike_comment(cid);
        });

        $('.reply-comment').on('click', function(){
        	var cid = $(this).data('cid');
        	show_comment_reply_box(cid);
        });

        $('#send_comment_btn').click(
            function(){
                if($('#my_comment').val() == '' || $('#my_comment').val().search(/\S/) == -1){
                    alert('Please post a comment');
                }else{
                    $('#send_comment_btn').css('display','none');
                    $('#btn_loader_alt').css('display','block');
                    $.post(
                        '/news/savecommentsajax/',
                        {
                            post: $('#add_comment_form').serialize(),
                            onglet : $('body').attr('class')
                        },
                        function(data){
                            var json_str = '';

                            if(data.indexOf('{') > -1){
                                json_str = $.parseJSON(data);
                            }

                            if(json_str.error){
                                alert(json_str.error);
                                window.prompt("Copy to clipboard: Ctrl+C, Enter", text);
                            }else{
                                if ($('#all_comments').children('.news_comment_box').length >= 3)
                                    $('#all_comments').children('.news_comment_box').last().remove();
                                $('#all_comments').prepend(data);                            
                                $('#nb_comments_span').html(parseInt($('#nb_comments_span').html())+1);
                                $('#my_comment').val('');				
                                $('#btn_loader_alt').css('display','none');
                                $('#send_comment_btn').css('display','block');
                                $('#add_comment_form').toggle("slow");
                                $('#add_comment_btn div.comment_show_hide_btn').toggle();
                            }
                        }
                        );
                }
            }
            );

    }
    );

function show_comment_reply_box(comment_id) {
	if($('#newscommentreply_textarea_div_'+comment_id).css('display') == 'none') {
		$('#newscommentreply_textarea_div_'+comment_id).show('slow');
		$('#comment_reply_btn_div_'+comment_id).hide('slow');
	}
}

function hide_comment_reply_box(comment_id) {
	$('#newscommentreply_textarea_div_'+comment_id).hide('slow');
	$('#comment_reply_btn_div_'+comment_id).show('slow');
}

function submit_comment_reply(comment_id) {
	if($('#my_reply_'+comment_id).val() == '' || $('#my_reply_'+comment_id).val().search(/\S/) == -1){
		alert('Please write your reply');
	}else{
                $('#send_comment_reply_btn_' + comment_id).css('display','none'); //added
		$('#send_comment_reply_div_'+comment_id).hide();
		$('#cancel_comment_reply_div_'+comment_id).hide();
		$('#loading_comment_reply_div_'+comment_id).show();
		$.post(
			'/news/savecommentsreplyajax/',
			{
                            post: $('#add_comment_reply_form_'+comment_id).serialize(),
                            onglet : $('body').attr('class')
			},
			function(data){
                            var json_str = '';

                            if(data.indexOf('{') > -1){
                                json_str = $.parseJSON(data);
                            }
                            
                            if(json_str.error){
                                alert(json_str.error);
                            }else{
				$('#all_comment_replies_'+comment_id).append(data);                            
				$('#my_reply_'+comment_id).val('');				
				$('#loading_comment_reply_div_'+comment_id).hide();
				$('#send_comment_reply_div_'+comment_id).show();
				$('#cancel_comment_reply_div_'+comment_id).show();
                                $('#send_comment_reply_btn_' + comment_id).css('display','block'); // added
				hide_comment_reply_box(comment_id);
                            }
			}
		);
	}
}

function like_comment(comment_id) {
	$('#loading_like_div_'+comment_id).show();

        $.ajax({
            type: 'POST',
            url:'/news/likecommentajax/',
            data: { 'comment_id' : comment_id },
            success:function(response){
                var json_str = '';

                if(response.indexOf('{') > -1){
                    json_str = $.parseJSON(response);
                }

                if(json_str.error){
                   alert(json_str.error); 
                }else{
                    var like_results_new = $(response).filter('#like_comment_new').html();

                    $('#like-comment-'+comment_id).html(like_results_new);
                }
            },
            failure:function(){
	           alert("Like failed.");
            }
        });

}

function unlike_comment(comment_id) {
	$('#loading_like_div_'+comment_id).show();

        $.ajax({
            type: 'POST',
            url:'/news/unlikecommentajax/',
            data: { 'comment_id' : comment_id },
            success:function(response){
                var json_str = '';

                if(response.indexOf('{') > -1){
                    json_str = $.parseJSON(response);
                }

                if(json_str.error){
                   alert(json_str.error); 
                }else{
                    var like_results_new = $(response).filter('#like_comment_new').html();

                    $('#like-comment-'+comment_id).html(like_results_new);
                }
            },
            failure:function(){
	           alert("Unlike failed.");
            }
        });

}

function show_comments_likes(comment_id) {

	var user_display_name = $('#user_display_name').val();
	var like_users_str = '<span class="popup_close"><a href="#" title="Close Other People Who Likes"><img src="/image/responsive/close-cross.jpg" alt="Close"/></a></span>';

        like_users_str += '<div id="news_likes_container">';

        $.ajax({
            type: 'POST',
            url: '/news/commentslikes',
            data: {
                comment_id : comment_id
            },
            success: function(data){

                var liked = data.liked;
                var users_nb = data.users.length;

                var i_liked = liked.length > 0 ? 1 : 0;

                if( users_nb > 0 ){
                    like_users = data.users;

                    for(var i=0;i<users_nb;i++) {
                        if(like_users[i] != '' && like_users[i].display_name != user_display_name) {
                            like_users_str += '<div><img class="more_likes" src="'+like_users[i].photo+'" alt="user photography" />'+like_users[i].display_name+'</div>';
                        }
                    }

                    var people_person = '';

                    if(users_nb == 1) {
                        people_person = 'person';
                    }
                    else {
                        people_person = 'people';
                    }

                    like_users_str += '</div>';

                    openPopup('news_like_users_popup_box',like_users_str);

                    return false;
                }
                
            },
            dataType : 'json'
        });
}

$(document).on('click', '.show_comments_likes', function(){
    var comment_id = $(this).data('cid');
    show_comments_likes(comment_id);
});