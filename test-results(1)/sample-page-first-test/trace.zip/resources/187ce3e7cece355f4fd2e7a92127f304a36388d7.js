$(document).ready(function() {
    $(".fancybox").fancybox();

    $(".fancyboxinline").fancybox({
        width  : 800,
        height : 600,
        type   :'iframe'
    });
    $(".fancyboxvideochapters").fancybox({
        width  : (window.innerWidth * (90/100)),
        height : (window.innerWidth * (90/100)) * 0.4875,
        type   :'iframe'
    });
});