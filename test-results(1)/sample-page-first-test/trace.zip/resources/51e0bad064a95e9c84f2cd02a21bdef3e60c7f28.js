$().ready(function() {
    $('.socialmedia_choice .choice').bind('click',function(){
        $('#socialmedia_box').html('<div class="loader"></div>');
        //ajaxSocialmedia($(this).attr('id'));        
    });
    
    function ajaxSocialmedia(choice){
        splitChoice = choice.split('_');
        $('.socialmedia_choice .choice').removeClass('active');
        $('.socialmedia_choice #'+splitChoice[0]).addClass('active');
        $.ajax({
            url:'/socialmedia/ajax/'+choice,
            success:function(response){
                $('#socialmedia_box').html(response);                
                popupCreate();
                $('.socialmedia  .network .link').bind('click',function(e){
                    $('ul#networks_list').fadeToggle('800');
                    e.stopPropagation();
                });
                $('body').bind('click',function(){
                    $('ul#networks_list').fadeOut('800');
                });
                $('.socialmedia #networks_list li').bind('click',function(){
                    $('#socialmedia_box').html('<div class="loader"></div>');
                    ajaxSocialmedia($(this).attr('id'));        
                });
                $('.socialmedia #networks_list li').hover(
                    function () {
                        $(this).addClass("hover");
                    },
                    function () {
                        $(this).removeClass("hover");
                    }
                   );
                
            },            
            failure:function(){
                alert('Echec de requette ajax');
            }
        });
    }
    //ajaxSocialmedia($('.socialmedia_choice .active').first().attr('id'));
    
    //When you click on a link with class of poplight and the href starts with a # 
    

    //Close Popups and Fade Layer
    $(document).on('click', 'a.close, #fade',function() { //When clicking on the close or fade layer...
        $('#fade , .popup_block').fadeOut(function() {
            $('#fade, a.close').remove();  //fade them both out
        });
        return false;
    });
});

function popupCreate(){
    $('a.poplight').click(function(e) {
        e.preventDefault();
		
		var popID = $(this).attr('data-popid'); //Get Popup Name
        var popURL = $(this).attr('href'); //Get Popup href to define size
		
		//alert(popID);
		
        //Pull Query & Variables from href URL
        var query= popURL.split('?');
        var dim= query[1].split('&');
        var popWidth = dim[0].split('=')[1]; //Gets the first query string value
        var flashUrl  = $(this).attr('title');
        $('#iframe_youtube').remove();
        if (flashUrl != undefined && popID != 'popup_editprofile'){
        $('#' + popID).append('<iframe id="iframe_youtube" width="640" height="510" src="'+flashUrl+'" frameborder="0" allowfullscreen></iframe>');
        }//Fade in the Popup and add close button
        $('#' + popID).fadeIn().css({
            'width': Number( popWidth )
        }).prepend('<a href="#" class="close">X</a>');

        //Define margin for center alignment (vertical   horizontal) - we add 80px to the height/width to accomodate for the padding  and border width defined in the css
        var popMargTop = ($('#' + popID).height() + 80) / 2;
        var popMargLeft = ($('#' + popID).width() + 80) / 2;

        //Apply Margin to Popup
        
		$('#' + popID).css({
			'margin-top' : -popMargTop,
			'margin-left' : -popMargLeft
		});



        //Fade in Background
        $('#socialmedia_box').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
        $('#fade').css({
            'filter' : 'alpha(opacity=80)'
        }).fadeIn(); //Fade in the fade layer - .css({'filter' : 'alpha(opacity=80)'}) is used to fix the IE Bug on fading transparencies 

        return false;
    });
}