$().ready(function() {
    $('#all_choice').bind('click',function(){
        ajaxNews('all');
        return false;
    });
    $('.hubone_choice').bind('click',function(){
        ajaxNews('hubone');
        return false;
    });
    $('.hubtwo_choice').bind('click',function(){
        ajaxNews('hubtwo');
        return false;
    });


    //ajaxNews('all');/// Duplicate ajax action. To be removed soon.
    $(document).on('click', '#popupEditMorenews .Save', function(){
        var hub_one = $('#hub_one').val();
        var hub_two = $('#hub_two').val();
        var id_chosen = "";
        var news_choice=$('.news_choice a.active').attr("id").replace(/_choice/g, "");
	
        //alert('hub_one='+hub_one+'&hub_two='+hub_two);
        $.post(
            '/news/morenewshubinfo/',
            {
                hub_one:hub_one,
                hub_two:hub_two
            },			
            function(response){
				//alert(response);
				//exit;
				if(response[0].short_name== "") {
					hubone_value = response[0].subfacet_name;
				}
				else {
					hubone_value = response[0].short_name;
				}
				if(typeof(response[1])!="undefined" && response[1].short_name== "") {
					hubtwo_value = response[1].subfacet_name;
				}
				else if(typeof(response[1])=="undefined") {
					//alert('hello');
					hubtwo_value = '';
				}
				else {
					hubtwo_value = response[1].short_name;
				}
                $('#hubone_choice span.newsTabCenter').html(hubone_value);
                $('#hubtwo_choice span.newsTabCenter').html(hubtwo_value);
                  
                
            },
            'json'
            );
		
        $('#fade , .popup_block').fadeOut(function() {
            $('#fade, a.close').remove();  //fade them both out
        });
        
        if(news_choice=="hubone")
            id_chosen = hub_one;
        else{if(news_choice=="hubtwo") id_chosen = hub_two;}
        
        if(id_chosen!="")
            ajaxNews(news_choice,id_chosen);
    });
	


});

function ajaxNews(choice,id){
    if(id==null)
        id="";
    else
        id='specifiedid='+id;

    $('.news_choice a').removeClass('active');
    $('.'+choice + '_choice').addClass('active');
    $('#morenews_box .right_box').html("<div class='loader'></div>");
    $.ajax({
        url:'/news/morenewsajax/'+choice+'?'+id,
        success:function(response){
            $('#morenews_box').html(response);
        },
        failure:function(){
            $('#morenews_box').html("News request to the hub failed");
        }
    });		
}