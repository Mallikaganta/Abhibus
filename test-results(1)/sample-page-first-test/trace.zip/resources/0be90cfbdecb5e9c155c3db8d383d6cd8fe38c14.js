function scroll_if_anchor(href) {
    if(href){
        href = typeof(href) === "string" ? href : $(this).attr("href");

        var bheight = $(window).height();
        var percent = 0.15;
        var hpercent = bheight * percent;
        href = href.replace("#", "");
        var hrefLink = '[id="'+href+'"]';
  
        if(href !== '#' && href !== null && typeof($(hrefLink).offset()) !== "undefined") {
            var offset  = parseInt($(hrefLink).offset().top);
            // Older browser without pushState might flicker here, as they momentarily
            // jump to the wrong position (IE < 10)
            if($(hrefLink).length > 0) {

                $('html, body').animate({ scrollTop: offset - hpercent },1000);
                
            }
        }

    }
}    

// When our page loads, check to see if it contains and anchor
$(document).ready(function(){

    scroll_if_anchor(window.location.hash);

    // Intercept all anchor clicks
    $("a[href*='#']").on("click", function(){
        scroll_if_anchor($(this).attr("href"));
    }); 
});
