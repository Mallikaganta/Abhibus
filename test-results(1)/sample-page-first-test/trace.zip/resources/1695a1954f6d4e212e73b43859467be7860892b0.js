$().ready(function() {
    $(document).on('click', '#newsalert .Save', function(){
            var subscription = $('input:radio[name=subscription]:checked').val();   
	//alert($('input:radio[name=subscription]:checked').val());		
		
            $.post('/news/newsalertsubscription/',
            { subscription:subscription },			
            function(response){$('#newsalertsuccess').html(response);},
            'json'
            );
			$('#newsalert').css('display','block');
        
    });

});
