function show_news(){
	   reset();
           exaleadfiltersnewsajax();
           $('#search_news_filters_block').show();
      $('#search_results_news').show().attr('tabindex','0');
      $('#nav_news').addClass('active').parent('li.mp_nav_lis').attr('aria-selected','true');
    }
	
function show_video_news(){
	   reset();
           exaleadfiltersnewsajax();
           $('#search_news_filters_block').show();
      $('#search_results_video_news').show().attr('tabindex','0');
      $('#nav_video_news').addClass('active').parent('li.mp_nav_lis').attr('aria-selected','true');
    }
    
function show_all(clicked){
    	reset();
      $('#search_results_all').show();
      if( clicked == 1 ){
          $('#search_results_all').attr('tabindex','0');
      }
      $('#nav_all').addClass('active').parent('li.mp_nav_lis').attr('aria-selected','true');
    }

function show_pages(){
	   reset();
       $('#search_results_pages').show().attr('tabindex','0'); 
       $('#nav_pages').addClass('active').parent('li.mp_nav_lis').attr('aria-selected','true');
	 }
	
function show_docs(){
	   reset();
	   $('#search_results_docs').show().attr('tabindex','0');
	   $('#nav_docs').addClass('active').parent('li.mp_nav_lis').attr('aria-selected','true');
	 }
	
function reset(){
    $('#search_news_filters_block').hide();
    $('#search_results_news').hide();
    $('#search_results_video_news').hide();
    $('#search_results_all').hide();
    $('#search_results_pages').hide(); 
    $('#search_results_docs').hide();
    $('#nav_news').removeClass('active');
    $('#nav_video_news').removeClass('active');
    $('#nav_all').removeClass('active');
    $('#nav_pages').removeClass('active');
    $('#nav_docs').removeClass('active');
    
    $('div[tabindex="0"]').removeAttr('tabindex');
    
    $('#search .mp_nav_lis').attr('aria-selected','false');
    $('.search_results').removeAttr('tabindex');
}

function ajaxPaginate(page_type,page){
  
  onglet = $('#onglet').val();
  community = $('#community').val();
  query = encodeURI($('#query').val());
  sort = $('#sort').val();
  search_type = $('#search_type').val();

  if( search_type == "exalead" ){
      community = $('#intranet').val();
  }
  
  news_page = '1';
  video_news_page = '1';
  all_page = '1';
  docs_page = '1';
  pages_page = '1';
  
  if (page_type=="news") news_page = page;
  if (page_type=="video_news") video_news_page = page;
  if (page_type=="all") all_page = page;
  if (page_type=="docs") docs_page = page;
  if (page_type=="pages") pages_page = page;

  $.ajax({
            url: '/'+onglet+'/search/'+search_type+'?query='+query+'&community='+community+'&sort='+sort+'&ajax=1'+'&news_page='+news_page+'&video_news_page='+video_news_page+'&all_page='+all_page+'&docs_page='+docs_page+'&pages_page='+pages_page,
            success:function(response){
                   
                   $('#search_result_container').html(response);
                   if (page_type=="pages") show_pages();
                   if (page_type=="all") show_all();
                   if (page_type=="docs") show_docs();
                   if (page_type=="news") show_news();
                   if (page_type=="video_news") show_video_news();
            },
            failure:function(){
            alert("Search failed.");
       }
       });    
}

function exaleadfiltersnewsajax(){
    var onglet = $('body').attr('class');
    var intranet = $("#intranet").val();
    var subfacet_id = typeof($("#subfacet_id").val()) != "undefined" ? $("#subfacet_id").val() : '';

    $.ajax({
        url:'/search/exaleadfiltersnewsajax?onglet='+onglet+'&intranet='+intranet+'&subfacet_id='+subfacet_id,
        success:function(response){
            $('#search_news_filters').html(response);
        },
        failure:function(){
               alert("Search failed.");
        }
    });
}

$(document).ready(function() {
    
    $('#search-launch-mobile').bind('click',function(){
        var mobileSearch = $('input[name="searchType"]:checked').val();
        var onglet = $('#onglet_mobile_search').val();
        if(mobileSearch === "intranet"){
            search_talent_mobile('intranet', onglet);
        }else if(mobileSearch === "people"){
            search_talent_mobile('people', onglet);
        }else if(mobileSearch === "internet"){
            search_talent_mobile('internet', onglet);
        }
    });
    
    $('#advanced_search_btn').bind('click',function(){
	    onglet = $('#onglet').val();
		  community = $('#community').val();
		  query = $('#query').val();
		  sort = $('#sort').val();
		  search_type = $('#search_type').val();
		  ajaxSearch(onglet,query,community,sort,search_type);
      return false;
    });
    
    /*$('#advanced_search_exalead_btn').bind('click',function(){
	    onglet = $('#onglet').val();
		  intranet = $('#intranet').val();
		  query = $('#query').val();
		  sort = $('#sort').val();
		  search_type = $('#search_type').val();
		  ajaxExaleadSearch(onglet,query,intranet,sort,search_type);
      return false;
    });*/
    
    $('#advanced_people_search_btn').bind('click',function(){
		  country = $('#community').val();
		  query = $('#query').val();
		  ajaxPeopleSearch(onglet,query,community,sort,search_type);
      return false;
    });
    
    $('#searchBtn').click(function(){
  	  var onglet = $('#onglet').val();
  		onglet = onglet != '' && onglet != 'undefined' && onglet != undefined ? onglet : 'global';

  		page_id = $('#page_id').val();
  		query = $('#query').val();
  		category_id = $('#category_id').val();
  		from_date = $('#from_date').val();
  		to_date = $('#to_date').val();
  		content_type = $('#content_type').val();
      ajaxHubSearch(onglet,query,page_id,category_id,from_date,to_date,content_type);
      return false;
    });
    
    function search_talent_mobile(site, onglet){
            var onglet = onglet;
            var searchtxt = $("#search_box_mobile").val(); // document.getElementById('alt_navigation_input').value;
            location.href='/'+ onglet + '/search/'+ site + '?query='+searchtxt;					
    }
  
    function ajaxSearch(onglet,query,community,sort,search_type){
	      //alert('/search/'+search_type+'?query='+query+'&community='+community+'&sort='+sort+'&ajax=1');
        $.ajax({
            url:'/search/'+search_type+'?query='+query+'&community='+community+'&sort='+sort+'&ajax=1',
            success:function(response){
                $('#search_results').html(response);
            },
            failure:function(){
	           alert("Search failed.");
            }
        });		
    }
    
    function ajaxExaleadSearch(onglet,query,intranet,sort,search_type){
	      //alert('/search/'+search_type+'?query='+query+'&community='+community+'&sort='+sort+'&ajax=1');
              console.log();
        $.ajax({
            url : '/' + onglet + '/search/exalead?ajax=1&'+$('#exalead_search_form').serialize(),
            success:function(response){
                show_all(1);
                $('#search_results').html(response);
            },
            failure:function(){
	           alert("Search failed.");
            }
        });		
    }
    
    function ajaxHubSearch(onglet,query,page_id,category_id,from_date,to_date,content_type){
    	    //alert("clicked");
            $.ajax({
                url:'/'+onglet+'/search/hub?query='+query+'&page_id='+page_id+'&category_id='+category_id+'&from_date='+from_date+'&to_date='+to_date+'&content_type='+content_type,
                success:function(response){
    	           //alert("success");
                    $('#results_search_hub').html(response);
                },
                failure:function(){
    	           alert("Search failed.");
                }
            });		
        }
    
    function ajaxPeopleSearch(country,query){
        $.ajax({
            url:'/search/people?query='+query+'&country='+country,
            success:function(response){
                $('#search_results').html(response);
            },
            failure:function(){
	           alert("Search failed.");
            }
        });		
    }
});



