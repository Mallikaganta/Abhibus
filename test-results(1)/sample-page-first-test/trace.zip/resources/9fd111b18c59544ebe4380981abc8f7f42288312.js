$(document).ready(function(e){
    if( window.location.href.indexOf('/global/pages/restricted/get_together_webevent') < 0 ) {
        // Multiple Momindum iframe management
        var iframes = $('iframe[src*="api.momindum.com"]');

        if( iframes.length > 1 ){
            var momIds = [];
            var tmpl = '<iframe allowfullscreen="true" class="momindum_full_width" frameborder="0" height="100%" id="{{id}}" scrolling="no" src="{{src}}" width="100%"></iframe>';
            var parameters = '?autoplay=false&amp;displayHeader=false';
            $(iframes).each(function(idx){
                var curr = $(this);
                var curr_id = 'momIfrm'+idx;
                $(curr).attr('id', curr_id);
                if( idx > 0 ){
                    momIds.push( {'id' : curr_id, 'src' : $(curr).attr('src')});
                    $(curr).replaceWith('<div class="loader" data-id="'+curr_id+'"></div>');
                }
            });
            $('#momIfrm0').on('load', function(e){
                setTimeout(function(){
                    $(momIds).each(function(idx){
                        var curr = momIds[idx];
                        curr.src = curr.src.indexOf('?autoplay') > -1 ? curr.src : curr.src + parameters;
                        var new_ifrm = tmpl.replace('{{id}}',curr.id).replace('{{src}}',curr.src);
                        $('div[data-id="'+curr.id+'"]').replaceWith(new_ifrm);
                    });
                }, 2000);
            });
        }
    }
});