var openm = false;
var open_id = 0;
      
var edit = getParameterByName('edit'); 
      
// if( edit == '' ){      
//     document.domain = 'capgemini.com';
// }
        
$(document).ready(function(){

	 /* Collapsible start */
    $('div .questions').click(function(){
		$(this).next('div .answers').slideToggle();
    });
    $('.acc-button').click(function(){
        $(this).toggleClass('acc-toggled');
    });
	
    $('.open-all').click(function(){
                var currid = $(this).attr('id');               
		$('.accordions_'+ currid + ' .acc-button').addClass('acc-toggled');
		$('.accordions_'+ currid + ' .answers').show('slow');	
    });
	
    $('.close-all').click(function(){                
                var currid = $(this).attr('id');
		$('.accordions_'+ currid + ' .acc-button').removeClass('acc-toggled');
		$('.accordions_'+ currid + ' .answers').hide('slow');
    });
    /* Collapsible end */

    activeCarousel();
    
    $('.owl-prev').click(function(){
        activeCarousel();
    });
    
    $('.owl-next').click(function(){
        activeCarousel();
    });
    
    $(document).keypress(function(e){
        if ( e.which === 13 && $('.owl-prev').is(':focus') ) {
            activeCarousel();
        }
    });
    
    $(document).keypress(function(e){
        if ( e.which === 13 && $('.owl-next').is(':focus') ) {
            activeCarousel();
        }
    });
    
    function activeCarousel(){
        $('#carouselGroup').find('#slideshow-news').find('.owl-item').each(function(){
        if(!$(this).hasClass('active')){
            $(this).find('.item').find('a').attr("tabIndex", "-1");
        }else{
            $(this).find('.item').find('a').removeAttr("tabIndex");
        }
        });
        
        $('#carouselCountry').find('#slideshow-country-news').find('.owl-item').each(function(){
        if(!$(this).hasClass('active')){
            $(this).find('.item').find('a').attr("tabIndex", "-1");
        }else{
            $(this).find('.item').find('a').removeAttr("tabIndex");
        }
        });
    }
    
    
        //For IE 9+ html border not working
        //fixed with css
        $('table').each(function(){
            var tabBorder = $(this).attr('border');
            
            if(tabBorder === '1'){
                $(this).find('tbody, td').css('border-style', 'solid');
                $(this).find('tbody, td').css('border-width','0.1rem');
            }else if(tabBorder === '0'){
                $(this).css('border-width','0rem');
            }
        });

	$('.close_switcher').click(function() {
		$('.open_switcher').show();
		$('#sticky-footer').addClass('close');

	}); 

	$('.open_switcher').click(function(){
		$('.open_switcher').hide();
		$('#sticky-footer').removeClass('close');
    }); 
    

    // Toggle Search
    //var search_icon = $('#search-toggle-btn-icon');
    var search_btn = $('#search-toggle-btn');
    var search_filters = $('#new-search-block');
    $(search_filters).hide();

    $(search_btn).on('click', function(e) {
        e.preventDefault();
        $(search_filters).toggle();
        if( $(search_filters).css('display') == 'block' ){
            $(search_btn).attr('aria-expanded','true');
        }else{
            $(search_btn).attr('aria-expanded','false');
        }
        
        $('#menu_nav_id button').attr('aria-expanded','false');
        $('#top-nav-new-menu').hide();
        
        $('#sub-nav-wrapper').hide();
    });

    $('#menu_nav_id button').on('click', function(e) {
        e.preventDefault();
        $('#top-nav-new-menu').toggle();
        if( $('#top-nav-new-menu').css('display') == 'block' ){
            $('#menu_nav_id button').attr('aria-expanded','true');
        }else{
            $('#menu_nav_id button').attr('aria-expanded','false');
        }
        
        $(search_btn).attr('aria-expanded','false');
        $(search_filters).hide();
        
        $('#sub-nav-wrapper').hide();
    })

    $('#top-menu-list .btn_right').on('click', function(e){
        e.preventDefault();
        $('#top-nav-new-menu').hide();
        $('#menu_nav_id button').attr('aria-expanded','false');
        
        $('#sub-nav-wrapper').show();
        //$('.megamenu_primary .arrow').addClass('arrow-right'); 
    });

    // Toggle Menu
    var megamenu_primary = $('.megamenu_primary');
    var megamenu_div = $('.megamenu_div');
    
    function toggleMegamenu(e, id) {
        e.preventDefault();
        
        var mq = window.matchMedia("(min-width: 1101px)");
        
        
        var onglet = $('.megamenu-clone').data('onglet');
        var current_arrow = $(this).find('.arrow');

        $('.megamenu_primary .arrow').removeClass('arrow-180'); 

        $(megamenu_primary).attr('aria-expanded','false');
        $(megamenu_div).hide();

        if(openm == true && open_id == id){
            openm = false;
            open_id = 0;
            $('#'+id + ' .megamenu_primary').attr('aria-expanded','false');
            if(mq.matches) $('#header-desktop-new').css('position','fixed');
        } else {
            $('#'+id + ' .megamenu_primary .arrow').addClass('arrow-180'); 
            openm = true;
            open_id = id;
            $('#'+onglet+'_'+id+'_megamenu').show();
            $('#'+id + ' .megamenu_primary').attr('aria-expanded','true');
            if(mq.matches) $('#header-desktop-new').css('position','static');
        }
    }
    
    $(megamenu_primary).on('click',function(e){
        if($(this).hasClass('carets')) {
            var id = $(this).parent().attr('id');
            toggleMegamenu(e, id);
        }
    });

        //Open megamenu when "Enter" is press
        $(document).on('focusin','a.megamenu_primary.page',function(e){
            if(!$(this).hasClass('megamenu_no_topcat')){        
                $(document).keypress(function(f){
                    if ( f.which == 13 ) {
                        var id = $(this).parent().attr('id');
                        toggleMegamenu(e,id);
                    }
                });      
            }
        });
    
        $(document).on('click','.mobile_menu_close',function(e){
            var mm_id = $(this).parents('.secondary_nav_lis').attr('id');
            toggleMegamenu(e,mm_id);
        });

        $(document).on('focusout','.mega_menu_close_bottom',function(e){
            var mm_id = $(this).parents('.secondary_nav_lis').attr('id');
            toggleMegamenu(e,mm_id);
        });

        $('.mega_menu_close').click(function(e){
            e.preventDefault();
            var mm_id = $(this).parents('.secondary_nav_lis').attr('id');
            toggleMegamenu(e,mm_id);
        });
        

	// Header fixed
	$(window).scroll(function(e){
		if($(window).scrollTop() > 57 && ( ($('.megamenu-clone').height() + $('#header-desktop').height()) < $(window).height() ) && openm != true ) {
            $('#banner').css({
				'position':'fixed',
				'top':0,
				'z-index': 7777
            });
		} else {
			$('#banner').css({
				'position':'relative',
				'top':0
			});
            
            $('body').css('padding-top', '0');
			$('#search, #menu, #info-header').show();
		}
    });
    
    

    
    

	// Megemenu mobile
	/**
	* Menu
	**/
	old_html = $('.megamenu-mobile #secondary_nav_mobile, .megamenu-mobile #secondary_nav').html();

	$(document).on('click', '.return-nav', function(){
		window.history.back();
	});

	$('#select-country').change(function(){
		var url = $(this).val();
		window.location.href = url;
	});
	 
        $(document).on('click', '.open_nav_uls',
            function(e){
                e.preventDefault();
                var open = $(this).find('img').attr('src') == '/image/responsive/icon_chevron_large.gif' ? true : false;
                if(open){
                    $(this).attr('aria-expanded','true');
                    $(this).find('img').attr('src','/image/responsive/icon_chevron_down_large.gif');
                    $(this).parent().parent().parent().find('ul:first').show();
                }else{
                    $(this).attr('aria-expanded','false');
                    $(this).find('img').attr('src','/image/responsive/icon_chevron_large.gif');
                    $(this).parent().parent().parent().find('ul:first').hide();
                }

            }
        );

        $('#pages_menu_btn, #news_menu_btn').on('click', function(e){
            e.preventDefault();
            var open = $(this).find('img').attr('src') == '/image/responsive/icon_chevron_large_outline.gif' ? true : false;
            if(open){
                $(this).attr('aria-expanded','true');
                $(this).find('img').attr('src','/image/responsive/icon_chevron_down_large_outline.gif');
                $(this).parent().find('ul:first').show();
                if( document.getElementById('hub_news_menu') ){
                    $('#hub_news_menu').show();
                }
            }else{
                $(this).attr('aria-expanded','false');
                $(this).find('img').attr('src','/image/responsive/icon_chevron_large_outline.gif')
                $(this).parent().find('ul:first').hide();
                if( document.getElementById('hub_news_menu') ){
                    $('#hub_news_menu').hide();
                }
                $('#nacb_left_menu').find('img').attr('src','/image/responsive/icon_chevron_large.gif');
            }
        });
         
        // Show Active page and its parents + children
        
        $('.current-item').siblings('a.open_nav_uls').find('img').attr('src','/image/responsive/icon_chevron_down_large.gif');
        $('.current-item').parent('li').addClass('mm_lvl_current_item');
        $('.news_type .current-item').parent().find('button img').attr('src','/image/responsive/icon_chevron_down_large.gif');
        $('.page_type .current-item').find('button img').attr('src','/image/responsive/icon_chevron_down_large.gif');
        $('.current-item').parent().find('ul.mm_lvl_uls:first').show();
        $('.current-item').parent().find('ul.mm_lvl_uls:first').find('li').attr('background', '#FFFFFF !important');
        
        $('.current-item').parents('ul.mm_lvl_uls').show();
        $('.current-item').parents('ul.mm_lvl_uls').siblings('a.open_nav_uls').find('img').attr('src','/image/responsive/icon_chevron_down_large.gif');
        
        // Show Active news and its parents 
        $('#sidebar_nav .tpl3Subnav li.active').parents('ul.tpl3Subnav').show();
        $('#sidebar_nav .tpl3Subnav li.active').parents('ul.tpl3Subnav').siblings('a.open_nav_uls').find('img').attr('src','/image/responsive/icon_chevron_down_large.gif');

        function validateDifferentUsercities(form){
            var errorsDiv = $("div.editusercitiesForm div.errors");
            errorsDiv.hide();
            var no_error = true;
            var allValues = new Array();
            $(form).find("select.cities option:selected").each(function(){
                if($.inArray($(this).val(),allValues)!=-1){
                    errorsDiv.show("fast");
                    no_error=false;
                }
                allValues.push($(this).val());
            });

            return no_error;
        }

        //use it on input with onblur event to fill the value
        function fill_input(element,defaultValue){
            if(element.value==""){
                element.value=defaultValue;
            }
        }
        //use it on input with onfocus event to empty the value
        function empty_input(element,defaultValue){
            if(element.value==defaultValue){
                element.value="";
            }
        }

        function resizeFrame(idString) {
        f = document.getElementById(idString);

        f.style.height = (f.contentWindow.document.body.scrollHeight+5) + "px";

        }


        $(function() {
         $(window).scroll(function() {
          if($(this).scrollTop() != 0) {
           $('#toTop').fadeIn();
          } else {
           $('#toTop').fadeOut();
          }
         });

         $('#toTop').click(function() {
          $('body,html').animate({scrollTop:0},800);
         });

        });
        
        $(document).on('click','.pause-btn', function(){
            owl.trigger('owl.stop');
            
            $('#slideshow-news-carousel-pause-btn').hide();
            $('#slideshow-news-carousel-play-btn').show();
        });
        
        $(document).on('click','.play-btn', function(){
            owl.trigger('owl.play', 5000);
            
            $('#slideshow-news-carousel-play-btn').hide();
            $('#slideshow-news-carousel-pause-btn').show();
        });
        
$('a[title=" (New Window)"]').attr('title','');

if( window.location.href.indexOf('/global/pages/restricted/get_together_webevent') < 0 ) {
    initMomindum();
}
});

function initMomindum(){
    // Multiple Momindum iframe management
    var iframes = $('iframe[src*="momindum.com/watch"]');

    if( iframes.length > 1 ){
        var momIds = [];
        var firstV = [];
        var tmpl = '<iframe allowfullscreen="true" class="momindum_full_width" frameborder="0" height="100%" id="{{id}}" scrolling="no" src="{{src}}" width="100%"></iframe>';
        var parameters = '?autoplay=false&amp;displayHeader=false';
        $(iframes).each(function(idx){
            var curr = $(this);
            var curr_id = 'momIfrm'+idx;
            $(curr).attr('id', curr_id);
            
            $(curr).replaceWith('<div class="loader" data-id="'+curr_id+'"></div>');
            
            if( idx > 0 ){
                momIds.push( {'id' : curr_id, 'src' : $(curr).attr('src')});
            }else{
                firstV = {'id' : curr_id, 'src' : $(curr).attr('src')};
            }            
        });

        var curr = firstV;
        
        $.get( curr.src, function( data ) {
            setTimeout(function(){
                var new_ifrm = tmpl.replace('{{id}}',curr.id).replace('{{src}}',curr.src);
                $('div[data-id="'+curr.id+'"]').replaceWith(new_ifrm);
                setTimeout(function(){
                $(momIds).each(function(idx){
                    setTimeout(function(){
                        var curr = momIds[idx];
                        curr.src = curr.src.indexOf('?autoplay') > -1 ? curr.src : curr.src + parameters;
                        var new_ifrm = tmpl.replace('{{id}}',curr.id).replace('{{src}}',curr.src);
                        $('div[data-id="'+curr.id+'"]').replaceWith(new_ifrm);
                    }, 2000);
                });
                }, 5000);
            }, 2000);
        });
    }
}

function printCurrentPage(){
    window.print();
}

function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return '';
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}