$(document).ready(function() {
   
    if( document.getElementById("cookie_info") ){
        // get cookie details to check acceptance of cookie
        var val = getCookie('AcceptanceForCookieUse');

        if(val == 1){	
            document.getElementById("cookie_info").style.display = 'none';
        }
    }
    
    if( document.getElementById("IE8browser_info") ){
        var ver = getInternetExplorerVersion();
            //var val = getCookie("IEbrowser");
                            //alert(val);
        if (ver > -1) {

            if (ver >= 8.0) {			
                            //var val = getCookie("IEbrowser");
                            var val = getCookie('IEBrowser');
                            if(val == 'IE8'){	
                                document.getElementById("IE8browser_info").style.display = 'none';
                            } else {
                                document.getElementById("IE8browser_info").style.display = 'block';
                            }

                    }
        }

    }
    
   
    //When you click on a link with class of poplight and the href starts with a # 
    $('a.poplight[href^=#], .poplight').click(function() {
        $("#header-mobile").hide();
        $('.menu-hide').hide();
        
        var popID = $(this).attr('data-popid'); //Get Popup Name
        
        if ($(this).attr('data-popid') == 'popup_usercities'){
            $.ajax({
                url:'/editusercities/editusercities',
                data: "redirect_url="+window.location.pathname,
                success:function(response){
                    openPopup(popID,response);
                }
            });
        }
        if ($(this).attr('data-popid') == 'popup_editprofile'){
            $.ajax({
                url:'/editprofile/display',
                success:function(response){
                    openPopup(popID,response);
                }
            });
        }
        if ($(this).attr('data-popid') == 'popup_morenewsedit'){
            $.ajax({
               url:'/news/morenewsedit',
               success:function(response){
                   openPopup(popID,response);
               }
            });
        }
        if ($(this).attr('data-popid') == 'popup_businesscard'){
            $.ajax({
               url:'/businesscard/'+$(this).attr('id'),
               success:function(response){
                   openPopup(popID,response);
               }
            });
        }
		if ($(this).attr('data-popid') == 'popup_sendtofriend'){
			//alert('hello');
			$.ajax({
               url:'/news/sendtofrienddisplay',
			   success:function(response){
                   openPopup(popID,response);
               }
            });
        }
		if ($(this).attr('data-popid') == 'popup_watch_this_page'){
			//alert('hello');
			$.ajax({
               url:'/index/watchthispagedisplay',
			   success:function(response){					
                   openPopup(popID,response);
               }
            });
        }
		if ($(this).attr('data-popid') == 'popup_newsalert'){
			//alert('hello');
			$.ajax({
               url:'/news/newsalertdisplay',
			   success:function(response){					
                   openPopup(popID,response);
               }
            });
        }
        
        return false;
    });
});
function openPopup(popID,popup_content){
    $('body .container').attr('aria-hidden',true);
  $('a, input, select, button').not('#' + popID+' a, #' + popID+' input, #' + popID+' select, #' + popID+' button').attr('tabindex','-1');
  
  $('#' + popID+' a, #' + popID+' input, #' + popID+' select, #' + popID+' button').filter(':first').attr('tabindex','0');
    
  $('.popup_block').remove();
  $('.shaddow').show();
  $('<div id="'+popID+'" class="popup_block"></div>').appendTo('body');
  $('#' + popID).html(popup_content).show();

  $('.popup_close').on('click', function(e){
      e.preventDefault();
    closePopup(popID);
  });
  
    $(document).keyup(function(e) {
      if (e.keyCode == 27) { closePopup(popID); }   // escape key maps to keycode `27`
    });
 
}

function closePopup(popID){
    $('body .container').removeAttr('aria-hidden');
    $('a, input, select, button').removeAttr('tabindex');
    
  $('#'+popID).remove();
  $('.shaddow').hide();
  
  $('a[data-popid="'+popID+'"]').focus();
}

// write a cookie for acceptance of cookie 
function setCookie() {

    var d = new Date();
    d.setMonth( d.getMonth() + 12 );
    var exp = d.toUTCString();
    
    document.cookie = 'AcceptanceForCookieUse=1; expires='+exp+'; path=/';    
    
    return true;
}
function getInternetExplorerVersion() {

    var rv = -1; // Return value assumes failure.

    if (navigator.appName == 'Microsoft Internet Explorer') {

        var ua = navigator.userAgent;

        var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");

        if (re.exec(ua) != null)

            rv = parseFloat(RegExp.$1);

    }

    return rv;

}
// check if acceptance of cookieis set
function getCookie(ckname) {

    var allcookie = document.cookie;
    var cookiearr = document.cookie.split(';');

    for(var i = 0; i < cookiearr.length; i++){
	var cname = cookiearr[i].split('=')[0];
	var cval = cookiearr[i].split('=')[1];
	cname = $.trim(cname);
	if(cname == ckname) {
	    return cval;
	}
    }
    
    return false;

}

// hide acceptance of cookie popup
function hideCookie() {
    
    setCookie();    
    if(document.getElementById("cookie_info")){	
	document.getElementById("cookie_info").style.display = 'none';
    }
    
}

function IEbrowserPopup() {
	var d = new Date();
	d.setTime(d.getTime()+(1*24*60*60*1000));
        var d2 = new Date(d.getFullYear(), d.getMonth(), d.getDate()+1, 2, 0, 0);
    //document.cookie = "IEBrowser=IE8"; expires="+d.toUTCString()+"; path="/";
    document.cookie = 'IEBrowser=IE8; expires='+d2.toUTCString()+'; path=/';
    document.getElementById("IE8browser_info").style.display = 'none';    
}