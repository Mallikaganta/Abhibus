$().ready(function() {
    $('#yammer_choice button').bind('click',function(){
        ajaxLinks('yammer',1);
        return(false);
    });
    $('#yammer_comp_choice button').bind('click',function(){
        ajaxLinks('yammercomp',1);
        return(false);
    });
    $('#all_choice button').bind('click',function(){
        ajaxLinks('all',1);
        return(false);
    });
    $('#toolcenter_choice button').bind('click',function(){
        ajaxLinks('toolcenter',1);
        return(false);
    });
    $('#toolcenterglobal_choice button').bind('click',function(){
        ajaxLinks('toolcenterglobal',1);
        return(false);
    });
    $('#morenews_choice button').bind('click',function(){
        ajaxLinks('morenews',1);
        return(false);
    });
    $('#essentials_choice button').bind('click',function(){
        ajaxLinks('essentials',1);
        return(false);
    });
    $('#global_choice button').bind('click',function(){
        ajaxLinks('global',1);
        return(false);
    });
    $('#mylinks_choice button').bind('click',function(){
        ajaxLinks('mylinks',1);
        return(false);
    });
    
});
function ajaxLinks(choice, clicked){
    $('#toolCenter').hide();
    $('#toolCenterGlobal').hide();
    $('.morenews').hide();
    $('#mylinks_edit').hide();
    $('.shortcuts_choice li').removeClass('active');
    $('#'+choice + '_choice').addClass('active');
    $('#shortcutsGroup').removeClass();
    $('#shortcutsGroup').addClass(choice+'Group');
	$('#shortcutsCountry').removeClass();
    $('#shortcutsCountry').addClass(choice+'Group');
    
    $('div[tabindex="0"]').removeAttr('tabindex');
    $('.scCentralTab').parent('li').attr('aria-selected','false');
    
    $('#'+choice+'_choice').attr('aria-selected','true');
    
    if(choice == 'all'){
         ajaxNews('all');
        $('#toolCenter').hide();
        $('#toolCenterGlobal').hide();
        $('#shortcuts_box').hide();
        $('.morenews').show();
        
        if( clicked == 1 ){
            $('.morenews').attr('tabindex','0').focus();
        }
        
    }else if(choice != 'toolcenter' && choice != 'toolcenterglobal' && choice != 'yammer' && choice != 'yammercomp'){
        $('#shortcuts_box').html('<div class="loader"></div>');
                
        if( clicked == 1 ){
            $('#shortcuts_box').attr('tabindex','0').focus();
        }
                
        $.ajax({
            url:'/shortcuts/ajax/'+choice,
            success:function(response){                
                $('#shortcuts_box').html(response);                 
                editMyLink();
                viewallGlobalLink();
            },            
            failure:function(){
                alert('Echec de requette ajax');
            }
        });
        $('#shortcuts_box').show();
    }else if(choice == 'toolcenterglobal' ){
        $('#shortcuts_box').hide();
        $('#toolCenter').hide();
        $('#toolCenterGlobal').show();
        if( clicked == 1 ){
            $('#toolCenterGlobal').attr('tabindex','0').focus();
        }
    }else if(choice == 'yammer' ){
        
        $.getScript("https://assets.yammer.com/assets/platform_embed.js", function(){
                    $('#shortcuts_box').html('<div class="loader"></div>');
            $.ajax({
                url:'/shortcuts/yammer/'+choice,
                success:function(response){      
                    $('#shortcuts_box').html(response);                 

                },            
                failure:function(){
                    alert('Echec de requette ajax');
                }
            });
            $('#shortcuts_box').show();
            if( clicked == 1 ){
                $('#shortcuts_box').attr('tabindex','0').focus();
            }
        });

        }else if(choice == 'yammercomp' ){
        
        $.getScript("https://assets.yammer.com/assets/platform_embed.js", function(){
                    $('#shortcuts_box').html('<div class="loader"></div>');
            $.ajax({
                url:'/shortcuts/yammercomp/',
                success:function(response){      
                    $('#shortcuts_box').html(response);                 

                },            
                failure:function(){
                    alert('Echec de requette ajax');
                }
            });
            $('#shortcuts_box').show();
            if( clicked == 1 ){
                $('#shortcuts_box').attr('tabindex','0').focus();
            }
        });

    }else{
        $('#shortcuts_box').hide();
        $('#toolCenter').show();
        if( clicked == 1 ){
            $('#toolCenter').attr('tabindex','0').focus();
        }
    }
    if( clicked == 1 ){
        setSNCookie('shortcuts_box_'+$('body').attr('class'), choice, 365);
    }
}    
function editMyLink(){
    $('.edit_link').bind('click',editMylinkfunction);
} 
function viewallGlobalLink(){
    $('.viewall_link').bind('click',viewallGloballinkfunction);    
}   
function viewallGloballinkfunction(){
    $('#mylinks_edit').html('<div class="loader"></div>');
    $.ajax({
        url:'/shortcuts/ajax/viewallGloballinks',
        success:function(response){
            $('#mylinks_edit').html(response);
			$('body').append('<div class="mask"></div>');
			$('#toolCenter').css('z-index', '1');
			$('.mask').css('opacity', '0.85');
            $('#list_categories_div ul li').each(function(){
                $(this).hover(function(){
                    $(this).addClass('hover');
                },function(){
                    $(this).removeClass('hover');
                });
                var idCat = parseInt($(this).children('div.id_cat').html());
                $(this).bind('click',function(){displayLinksByCategory(idCat);});
                var idCatFirst = parseInt($('#list_categories_div ul li').first().children('div.id_cat').html());
                displayLinksByCategory(idCatFirst);
            });
            
            $('#mylinks_edit').fadeIn('500');  
			 if($.browser.msie && parseInt($.browser.version, 10) == 7) {
				$('#mylinks_edit').css('top', '35px');        
			}
        }
    });
}
function displayLinksByCategory(idCat){
    $('#list_categories_div ul li').removeClass('active');
    $('#category_li_'+idCat).addClass('active');
    $('#list_links_div').html('<div class="loader"></div>');
    $.ajax({
        url:'/shortcuts/ajax/viewalllinks',
        data:"idCat="+idCat,
        success:function(response){
            $('#list_links_div').html(response);
        }                
    });
    $('#close_btn, .mask').bind('click',function(){
        $('#mylinks_edit').fadeOut('500');
		$('.mask').remove();
		$('#toolCenter').css('z-index', '1000');
    });
}
function editMylinkfunction(){
    $('#myLinksDiv').html('<div class="loader"></div>');
    $.ajax({
        url:'/shortcuts/ajax/editlinks',
        success:function(response){
            $('#myLinksDiv').html(response);

            $('.resetItemLink').bind('click',function(){
                editMylinkfunction(); 
            });
            $('#editlinks_form').submit(function() {
                var error = '';
                if($('#linkName').val() == '')
                {
                        error = 'Please enter link name.';
                }
                else if($('#linkUrl').val() == '')
                {
                        error = 'Please enter link URL.';
                }

                if(error != '')
                {
                        $('#linkError').html(error);
                        $('#linkError').show();
                        return false;
                }
                else
                {
                        $('#linkError').val('');
                        $('#linkError').hide();
                        $('#mylinks_edit').fadeOut('500');
                        $('#toolCenter').css('z-index', '1000');
                        $('.mask').remove();
                }
				
                renamePosition();
                $.ajax({
                    type: "POST",
                    url: "/shortcuts/ajax/savemylinks",
                    data: $(this).serialize(),
                    success: function(msg){
                        ajaxLinks('mylinks'); 
                    }
                });
                return false;
            });
            $('.addItemLink').bind('click',function(){
                $('#list_editlinks').append('<li ><img class="move" src="/image/modules/shortcuts/sortable.gif"/>'+
                    '<input type="text" value="Name" name="name" id="linkName"/>'+
                    '<input type="text" value="URL" name="url" id="linkUrl"/>'+
                    '<a href="javascript:void(0)" class="cross" title="Delete Link"><img width="12px" src="/image/modules/shortcuts/delete.png" alt="Delete Link" /></a></li>') ;
                $('#list_editlinks li a.cross').bind('click',function(){
                    $(this).parent('li').remove();
                });
            });
            $('#list_editlinks li a.cross').bind('click',function(){
                $(this).parent('li').remove();
            });
            $(".editlinks.shortcuts .sortable").sortable({
                cursor: 'move',
                handle: 'img.move'
                ,
                update:editlinksUpdate
            });
        },            
        failure:function(){
            alert('Echec de requette ajax');
        }
    });
}

function renamePosition(){
    var ulList = $('#list_editlinks');
    ulList.children('li').each(function(ind,elem){
        $(elem).children('input').each(function(indInput,elemInput){
            $(elemInput).attr('name',$(elemInput).attr('name')+'_'+ind);  
        });      
    });
}

function editlinksUpdate(event,ui){
    
}

function setSNCookie(cname, cvalue, exdays) {
    $.ajax({
        type: "POST",
        url: "/shortcuts/savetab",
        data: {
            'sname' : cname,
            'svalue' : cvalue
        }
    });
}