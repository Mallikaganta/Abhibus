
$(document).on('mouseup', function (e)
{
    var container = $(".mainSearchBar").find("button");
    if (!container.is(e.target) && container.has(e.target).length === 0){
        $('.search_dropdown_menus').hide();
        $('.dropdown_search_caret').attr("aria-expanded", false);
    }
});
function search_talent(site){
        var onglet = $('body').attr('class');
        var searchtxt = document.getElementById('alt_navigation_input').value;
        switch(site){
            case 'internet' :
                 window.open('https://www.google.com/#q='+searchtxt, '_blank');
            break;
            case 'hubs' :
                 location.href='/'+ onglet + '/search/intranet?query='+searchtxt+'&community=hubs';
            break;
            case 'university' :
                 location.href='/'+ onglet + '/search/intranet?query='+searchtxt+'&community=university';
            break;
            default :
                location.href='/'+ onglet + '/search/'+ site + '?query='+searchtxt;	
        }
}

$(document).on('click','.top_searchtype', function(e){
    var onglet = $('body').attr('class');
    var searchtype = $(this).data('searchtype');
    var searchid = $(this).data('searchid');
    var search_label = $(this).html();

    $(this).parents('.top_search_forms').find('.dropdown_search_caret .top_search_labels').html(search_label);

    $(this).parents('.top_search_forms').attr('action', searchtype);
    $(this).parents('.top_search_forms').find('.top_search_action_ids').val(searchid);
    
    
});

$(document).on('click','.top_search_btns', function(e){
    
    $(this).parents('.top_search_forms').find('.ou_course_searches').val($(this).parents('.top_search_forms').find('.alt_navigation_inputs').val());
    
    $(this).parents('.top_search_forms').submit();
});

function toggleClocks() {
	div = document.getElementById("alt_navigation_clocks");
	if (div.style.display == '' || div.style.display == 'none') {
		div.style.visibility = 'visible';
		div.style.display = 'block';
		document.getElementById("clock_icon").src="/image/alt_nav/clock_invert.jpg";
		document.getElementById("euro_icon").src="/image/alt_nav/euro.jpg";
                

                $('div[tabindex="0"]').removeAttr('tabindex');
                $('#alt_navigation_clocks').attr('tabindex','0').focus();
                
                $('#alt_navigation_clock').attr('aria-expanded', true);
                $('#alt_navigation_euro').attr('aria-expanded', false);
                
	} else {
		div.style.display = 'none';
		document.getElementById("clock_icon").src="/image/alt_nav/clock.jpg";
                
                $('div[tabindex="0"]').removeAttr('tabindex');
                
                $('#alt_navigation_clock').attr('aria-expanded', false);
	}


	div2 = document.getElementById("alt_navigation_share_price");
	div2.style.display = 'none';

}

function toggleSharePrice() {
	div = document.getElementById("alt_navigation_share_price");
	if (div.style.display == '' || div.style.display == 'none') {
		div.style.visibility = 'visible';
		div.style.display = 'block';
		document.getElementById("euro_icon").src="/image/alt_nav/euro_invert.jpg";
		document.getElementById("clock_icon").src="/image/alt_nav/clock.jpg";
                
                $('div[tabindex="0"]').removeAttr('tabindex');
                $('#alt_navigation_share_price').attr('tabindex','0').focus();
                
                $('#alt_navigation_euro').attr('aria-expanded', true);
                $('#alt_navigation_clock').attr('aria-expanded', false);
                
	} else {
		div.style.display = 'none';
		document.getElementById("euro_icon").src="/image/alt_nav/euro.jpg";
                
                $('div[tabindex="0"]').removeAttr('tabindex');
                
                $('#alt_navigation_euro').attr('aria-expanded', false);
	}


	div2 = document.getElementById("alt_navigation_clocks");
	div2.style.display = 'none';


}

$(document).on('click', '.dropdown_search_caret', function(e) {
    var ariaExpanded    = $(this).attr("aria-expanded");
    var dropdown        = $(this).parents('.top_search_forms').find('.search_dropdown_menus').css("display");
    
    if(dropdown === "none"){ 
        $(this).attr("aria-expanded", true);
        $(this).parents('.top_search_forms').find('.search_dropdown_menus').css("display", "block");
    }
    else if(dropdown === "block"){
        $(this).attr("aria-expanded", false);
        $(this).parents('.top_search_forms').find('.search_dropdown_menus').css("display", "none");
    }
    
    //$(this).parents('.top_search_forms').find('.search_dropdown_menus').toggle();
});