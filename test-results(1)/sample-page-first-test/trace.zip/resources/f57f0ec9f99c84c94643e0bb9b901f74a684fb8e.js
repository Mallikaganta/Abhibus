$(document).ready(function(){
    //dropdown_menus();
    
    $(document).on('click', '.dropdown-menu-btn', function(e){
        e.preventDefault();
        $('.dropdown-menu-btn').toggleClass('active','inactive');
         $('.dropdown-menu-ul').toggleClass('active','inactive');

    });
    
    $(document).on('click', '.dropdown-menu-li-a', function(e){
        e.preventDefault();
        
        var spans = $(this).html();
        
        $('.dropdown-menu-btn').val($(this).data('value')).html(spans+'<span class="dropdown-menu-sort fa fa-sort"></span>').toggleClass('active','inactive');
        
       $(this).parents('form#top_search_form').attr('action', '/'+$('body').attr('class')+'/search/'+$(this).data('value'));
        
        //console.log($(this).parent('form').find('.dropdown-menu-hdn'));
        
        $(this).parent('form').find('.dropdown-menu-hdn').val($(this).data('value'));
        
        $('.dropdown-menu-ul').toggleClass('active','inactive');
    });
    
    $(document).on('click', '#show-search', function(){
        $( "#top_search_form" ).toggleClass('active');
    });
    
    /*$(document).keypress(function(e) {
        if(e.which == 13 && $('input[name=query]').is(':focus') ) {
            e.preventDefault();
            $(':focus').parents('form#top_search_form').find('#search-launch').click();
        }
    });*/
    
});



function dropdown_menus(){
    var selects = $('.dropdown-menu');

    $(selects).each(function(index){
        var select = $(this);

        var sid = $(select).attr('id');
        
        var main_container = $('<div>', {
            'id' : sid+'-block',
            'class' : 'dropdown-menu-block'
        });

        var launch_button = $('<button>', {
            'id' : sid+'-btn',
            'class' : 'dropdown-menu-btn inactive'
        });
        
        var options_list = $('<ul>', {
            'id' : sid+'-ul',
            'class' : 'dropdown-menu-ul inactive'
        });
        
        var hidden_field = $('<input>', {
            'id' : sid,
            'name' : sid,
            'type' : 'hidden',
            'class' : 'dropdown-menu-hdn'
        });
        
        var options_str = '';
        
        $(select).find('option').each(function(idx){
            var option = $(this);
            
        //console.log($(this));
        //console.log($(option));
            
            var icon_str = option.data('icon') ? '<span class="dropdown-menu-li-icon fa '+option.data('icon')+'"></span>' : '';
            
            var spans_str = icon_str+'<span class="dropdown-menu-li-label">'+option.text()+'</span>';
            
            var li_str = '<a class="dropdown-menu-li-a" href="#" data-value="'+option.attr('value')+'">'+spans_str+'</a>';
            
            options_str += '<li class="dropdown-menu-li inactive">'+li_str+'</li>';

            if( idx == 0 ){
                $(launch_button).val(option.attr('value')).append(spans_str+'<span class="dropdown-menu-sort fa fa-sort" title="Select a search option"></span>');
            }
            
        });
        
        $(options_list).append(options_str);

        $(main_container).append($(launch_button), $(options_list), $(hidden_field));

        select.after($(main_container)).remove();
    });
}