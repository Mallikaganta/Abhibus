$(document).ready(function() {
	 $(document).on('click', '#watch_this_page .Save', function(){
                var choice_value = $('input:radio[name=choice]:checked').val();
		$.post(
                '/index/watchthispage/',
                {				
                    choice:choice_value,
                    page_value:window.parent.location.href
                },			
                function(response){
                    $('#success').html(response);
                    }
                );
                $('#sendPageForm').css('display','none');
                
                window.setTimeout(function(){
                    $('#popup_watch_this_page').remove();
                    $('.shaddow').css('display','none');
                }, 5000);
    });
});
